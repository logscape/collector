#!/bin/bash

groovyc -cp ../lib/http-builder-0.7/http-builder-0.7.jar:../lib/http-builder-0.7/dependencies/*  command.groovy bundles.groovy apps.groovy
groovyc -cp ../lib/http-builder-0.7/http-builder-0.7.jar:../lib/http-builder-0.7/dependencies/*  ./tests/Test*.groovy

jar cvf main.jar *.class

#groovy -cp ../lib/http-builder-0.7/http-builder-0.7.jar:../lib/http-builder-0.7/dependencies/*  testsuite.groovy

