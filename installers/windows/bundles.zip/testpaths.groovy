
new File(".././").listFiles().each(){ f->
	println f 
}
