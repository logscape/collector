def t = ["java","-version"].execute().text 
def t1 = "netstat -anop".split().execute().text

println t1