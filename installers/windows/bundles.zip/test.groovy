import groovy.util.GroovyTestSuite
import junit.framework.Test
//import junit.textui.TestRunner
//import org.codehaus.groovy.runtime.ScriptTestAdapter

/*
	/etc/services
	new AppProcessContext( config ) 
	AppProcessContext.getOutLogFile() 
*/


public class TestA extends GroovyTestCase {
	def apps=null

	void  setUp(){
	}
	void testGet(){
		fail("Not Yet Implemented") 
	}
}


