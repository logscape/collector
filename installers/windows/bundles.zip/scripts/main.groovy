import groovy.util.GroovyTestCase; 
import java.net.ServerSocket
import groovy.json.* 
import org.apache.log4j.*
import groovy.util.logging.* 


def get(map,k,defaultValue){
	if (map.containsKey(k)){
		return map[k]
	}
	return defaultValue 
}
def opts(arguments){
	def props=[:]
	for(def arg:arguments){
		if (arg.contains("=") ){
			def k=arg.split("=")[0]
			def v=arg.split("=")[1]
			props[k]=v 	
		}
	}
	return props
}

def properties = opts(args) 
def workingDirectory = get(properties,"workingDirectory","") 
def services_json = new JsonSlurper().parseText( new File(workingDirectory + "/" + "services.json").text )
def apps = new Apps() 
def processManager = new ProcessManager()
def bundles = new Bundles( services_json ) 
/*def bundles=new Bundles([
	"manager":"10.28.1.160:11000" 
	,"token":"123:456:789"
	,"apps":["unixapp"]
]) */
bundles.workingDirectory=workingDirectory
bundles.init() 
apps.workingDirectory=workingDirectory
apps.init() 

/*Start All Services*/
for(def bundleName: apps.apcs.keySet() ){
	println "[Starting] $bundleName "
	processManager.add(apps.apcs[bundleName])
	processManager.start(bundleName) 
}


def commander=new Commander() 

commander.addWorker( "apps", apps  ) 
commander.addWorker( "bundle", bundles  ) 
commander.addWorker( "pm", processManager ) 
commander.addWorker( "dummy", new DummyWorker() ) 


commander.register("module","action", { workers,args -> 
	def w=workers["dummy"] 
	return  w.method(args[0])
})

commander.register("bundle","list", { workers,args -> 
	def _bundle=workers["bundle"] 
	def _apps=_bundle.getAppList()
	def ret=""
	println "applist size: " + _bundle.getAppList().size() 
	for(def name:_apps.keySet()){
		ret=ret + name + ": << " + _apps[name]  + " >> \n " // + apps[name] + "\n" 
	}
	return ret
})

commander.register("bundle","install", { workers,args ->
	def bundleName=args[0] 
	def _bundles=workers["bundle"]
	_bundles.install(bundleName)
	return "installing [$bundleName]"
})

commander.register("process","start", { workers,args -> 

	def _pm=workers["pm"] 
	def _pTable = _pm.pTable 
	def _apps = workers["apps"] 
	def _appId  = args[0] 	
	if ( _apps.apcs.containsKey(_appId) == false ){
		return " Invalid bundle name [ $_appId ] " 
	}
	if (_pTable.containsKey(_appId)){
		return "[ProcessManager] $_appId is already running " 
	}
	def _apc = _apps.apcs[_appId] 
	_pm.add(_apc)
	_pm.start(_apc.getName() ) 
	def ret = " Process [" + _apc.getName() + "] started ! " 
	return ret 
});


commander.register("process","stop", { workers,args -> 

	def _pm=workers["pm"] 
	def _apps = workers["apps"] 
	def _appId  = args[0] 	
	def _apc = _apps.apcs[_appId] 
	_pm.add(_apc)
	_pm.stop(_apc.getName() ) 
	def ret = " Process [" + _apc.getName() + "] stopped ! " 
	return ret 
});



commander.register("process","list", { workers,args -> 
	def _pm=workers["pm"] 
	def ret=""
	println _pm.processes 
	for(def bundle:_pm.processes.keySet()){
		def p = _pm.processes[bundle] 
		ret=ret + "name: " + p.getName() + ", status:  [" + p.getStatusAsText() + "] \n"  
	}
	return ret 
});



commander.register("help","", { workers,args -> 
	def ret=""	
	ret= " ... " 
	return ret 
})

def server=new CommandServer(commander) 
server.init()
server.start() 


