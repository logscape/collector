while(true){
	println "" + new Date()   + "\t mooo" 
	sleep(30000) 
}
