public class TestApps extends GroovyTestCase {
	def apps=null

	void  setUp(){
		this.apps= new Apps() 
	}
	void testGet(){
		this.apps.init()
		def apc=this.apps.get("unixapp") 
		def expected="unixapp"
		assertEquals(expected,apc.getName())
	}
	void testGetAll(){
		this.apps.init() 
		def apps = this.apps.getAll() 
		println apps["unixapp"].configuration 
		assertEquals("moo", apps["unixapp"].get("tag") ) 
	}
}

