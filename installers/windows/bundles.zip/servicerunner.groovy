
while(true){
	def dt= new Date()
	println "" + dt + "\tEcho" 
	sleep(60*1000)
}