
public class TestProcessManager extends GroovyTestCase {
	def pm=null
	def apps=null
	void setUp(){
		this.apps=new Apps() 
		this.apps.init()
		this.pm= new ProcessManager() 
		
	}
	void testAddProcess(){
		def apc=this.apps.apcs["unixapp"]
		this.pm.add(apc)
		assertEquals(this.pm.processes["unixapp"].getName(),"unixapp")
	}

	void testDefaultStatus(){
		def apc=this.apps.apcs["unixapp"]
		this.pm.add(apc)
		def status = this.pm.processes["unixapp"].status
		assertEquals(status,AppProcessContext.STATUS_STOPPED)

	}
	void testStopProcess(){
		def apc=this.apps.apcs["unixapp"]
		this.pm.add(apc)
		this.pm.start("unixapp") 
		this.pm.stop("unixapp") 
		def status = this.pm.processes["unixapp"].status
		assertEquals(status,AppProcessContext.STATUS_STOPPED)

	}

	void testStartProcess(){
		def apc=this.apps.apcs["unixapp"]
		this.pm.add(apc)
		this.pm.start("unixapp") 
		def status = this.pm.processes["unixapp"].status
		assertEquals(status,AppProcessContext.STATUS_RUNNING)
	}

} 


