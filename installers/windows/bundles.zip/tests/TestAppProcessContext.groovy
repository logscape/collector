import groovy.json.*;


/*
		apc.getLogOutFile()
		apc.getLogErrFile()
		apc.getExecCommand() 

*/ 
public class TestAppProcessContext extends GroovyTestCase {
	def bundles=null;
	def apc=null;
	void setUp(){
		def configs=new JsonSlurper().parseText('{"unixapp":{"token":"123:456:789", "output":[{"port":"9991","type":"SocketOut","remoteAddr":"10.28.1.160"}],"bundleName":"UnixApp-1.1/UnixApp.bundle","serviceName":"*" , "tag":"moo"}} ')		
		this.apc= new AppProcessContext("unixapp",configs)  
	}
	void testGetName(){
		def expected = "unixapp"
		def bundleName = this.apc.getName() 
		assertEquals(expected,bundleName) 
	}

	void testGetCommand() {
		def expectedCmd=["java","-cp",".:./lib/*","com.liquidlabs.vso.deployment.ServiceTestHarness",this.apc.configuration]
		def cmd=this.apc.getCommand() 
		assertEquals(cmd,expectedCmd)
	}
	void testGetLogErrFile() {
		def logFile=this.apc.getLogErrFile() 
		def expected="./logs/unixapp.err" 
		assertEquals(expected,logFile) 
	}

	void testOutLogFile(){
		def logFile=this.apc.getLogOutFile() 
		def expected="./logs/unixapp.log" 
		assertEquals(expected,logFile) 
	}

}


