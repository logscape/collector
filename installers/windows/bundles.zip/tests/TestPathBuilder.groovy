
public class TestPathBuilder extends GroovyTestCase  {
	void testRelativePath(){
		def pb=new PathBuilder("../") 
		def path=pb.getPath("./work")
		def expected = "../work/"
		assertEquals(path,expected) 
	}

	void testAbsolutePath(){
		def pb=new PathBuilder("/home") 
		def path=pb.getPath("./work")
		def expected = "/home/work/"
		assertEquals(path,expected) 
	}

}

