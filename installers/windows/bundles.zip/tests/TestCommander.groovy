import groovy.util.GroovyTestCase; 
import java.net.ServerSocket
import groovy.json.* 
/*
def commander=new Commander() 
commander.addWorker( "dummy", new DummyWorker() ) 
commander.register("module","action", { workers,args -> 
	def w=workers["dummy"] 
	return  w.method(args[0])
})


def server=new CommandServer(commander) 
server.init()
server.start() 
*/ 

public class TestCommander extends GroovyTestCase {
	def commander=null

	void  setUp(){
		this.commander= new Commander() 
	}
	void testInvokeCommand(){
		this.commander.addWorker( "dummy", new DummyWorker() ) 
		this.commander.register("module","action", { workers,args -> 
			def w=workers["dummy"] 
			return  w.method(args[0])
		})
		def retVal=this.commander.invoke(module:"module",action:"action",args:"bob") 
		assertEquals("bob",retVal) 
	}

	void testRegisterOneModuleManyCommands(){
		this.commander.addWorker( "dummy", new DummyWorker() ) 
		
		commander.register("moduleA","action", { workers,args -> 
			def w=workers["dummy"] 
			return  w.method(args[0])
		})


		this.commander.register("moduleB","action1", { workers,args -> 
			def w=workers["dummy"] 
			return  w.method(args[0])
		})

		this.commander.register("moduleB","action2", { workers,args -> 
			def w=workers["dummy"] 
			return  "action2"
		})
		def retVal=this.commander.invoke(module:"moduleB",action:"action2",args:"bob") 
		assertEquals("action2",retVal) 

	}
}


