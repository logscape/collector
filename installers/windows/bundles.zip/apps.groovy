import groovy.util.*
import groovy.json.*;
import groovy.util.logging.*
import groovy.util.GroovyTestCase; 
import groovy.util.GroovyTestSuite; 
import org.apache.http.client.* 
import org.apache.http.client.methods.*;
import groovyx.net.http.*;
import groovyx.net.http.RESTClient;
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.JSON 
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.concurrent.*
import java.lang.ProcessBuilder 
import com.liquidlabs.vso.agent.process.* 

import org.apache.log4j.* 

def apps = new Apps()
apps.init() 

@Log4j
public class ProcessManager {
	def processes = null
	def pool = null
	def pTable = [:]
	def workingDirectory = "." 
	def ProcessManager(){
		this.processes = new ConcurrentHashMap() 
		this.pTable= new ConcurrentHashMap() 
		this.pool = Executors.newFixedThreadPool(10) 
	}

	
	def setWorkingDirectory(dir){
		this.workingDirectory=dir 
	}
	def shutdown(){
		log.info "shutdown start"
		this.pool.shutdown()
		log.info "shutdown successfull;"
	}
	def add(apc){
		def name = apc.getName()
		processes[name] = apc
		log.info "Adding app:$name" 
	}
	def start(name){
		log.info "START app:$name" 
		pool.submit{  
			exec(this.processes[name]) 
		} 
	}	
	def stop(name){
		if ( pTable.containsKey(name) == false){
			println "Process does not exist [ $name ] " 
		}
		kill(name) 
		processes[name].setStatus(AppProcessContext.STATUS_STOPPED) 
		log.info "STOP app:$name stopped"
		// close any file handles 
	}


	def kill(name){
		pTable[name].destroy()
		pTable.remove(name) 
		processes[name].setStatus(AppProcessContext.STATUS_STOPPED) 
		log.info "KILL app:$name"
	}
	def exec(apc){
		try { 
			def outFile=apc.getLogOutFile()
			def errFile=apc.getLogErrFile()
			def cmd=apc.getCommand(apc.name) 
			def line
			log.info "EXEC app:$apc.name cmd:" + cmd.join(" ")
			def pb=new ProcessBuilder(cmd)
			pb.redirectErrorStream(true)
			pb.directory(new File(this.workingDirectory)) 
			def process=pb.start() 
			pTable[apc.name] = process 
			processes[apc.name].setStatus(AppProcessContext.STATUS_RUNNING) 

			//def pu  = new ProcessUtils() 
			//def aProcess=pu.convertProcess(process)
			//println " The pid for this process is $aProcess.pid() " 
			//System.exit(0) 
			InputStream stdOut =  process.getInputStream();
			InputStream stdErr =  process.getErrorStream();
			BufferedWriter stdOutWriter = new BufferedWriter( new FileWriter(outFile));
			BufferedWriter stdErrWriter = new BufferedWriter( new FileWriter(errFile));
			BufferedReader reader = new BufferedReader(new InputStreamReader(stdOut))
			BufferedReader errReader = new BufferedReader(new InputStreamReader(stdErr))
			stdOutWriter.writeLine(""+ new Date() + "[Starting]")
			while((line = reader.readLine())!=null){
				stdOutWriter.writeLine(line);
				stdOutWriter.flush()
			}
			stdOutWriter.writeLine(""+ new Date() + "[Stopping]" ) 
			while((line = errReader.readLine())!=null){
				stdErrWriter.writeLine(line);
				stdErrWriter.flush()
			}
			
			stdOutWriter.close() 
			stdErrWriter.close() 
			process.waitFor()

			kill(apc.name) 


		}catch(Exception e){
			System.out.println("Error");
			e.printStackTrace();
			throw e;
		}
		 
	}

}

@Log4j
public class Apps {
	def apcs=null 
	def workingDirectory="."
	def setWorkingDirectory(dir){
		this.workingDirectory=dir
	}
	def load(confDir){
		log.info "LOAD configDir:$confDir" 
		def files=new File(confDir).listFiles() 
		def configs=[]
		for(def f:files){
			try{
				log.info "LOAD opening " +  new File(""+f).getPath() 
				def c=[:]
				def bundleName = f.name.split(".json")[0]  
				c[bundleName]=new JsonSlurper().parseText( new File(f.toString()).text )
				//c=new JsonSlurper().parseText( new File(f.toString()).text )
				//c["json"]=new File(f.toString()).text
				//c["log.out"]="./logs/"+f.name.replace(".conf","") + ".log" 
				//c["log.err"]="./logs/"+f.name.replace(".conf","") + ".err" 
				//c["command"]=["java","-cp",".:./lib/*","com.liquidlabs.vso.deployment.ServiceTestHarness",c["json"]]
				log.debug "LOAD ADDING CONFIG $c"
				configs.add(c) 
			}catch(Exception e){
				println e
				e.printStackTrace() 
			}
		}
		return configs 
	} 

	def get(bundle){
		if (this.apcs.containsKey(bundle) == false) {
			return null
		}
		return this.apcs[bundle] 
	}
	def getAll(){
		return this.apcs 
	}
	def init() {
		log.info "INIT Apps module" 
		this.apcs=[:] 
		def configs = load(new File(this.workingDirectory + "/" + "./etc/services").getPath())
		for(def c:configs){
			def bundleName = c.keySet().toArray()[0]
			def apc =  new AppProcessContext(bundleName,c[bundleName])
			apc.workingDirectory = new File(this.workingDirectory).getPath() 
			this.apcs[bundleName] = apc 
		}
	}
}

public class AppProcessContext {
	public static int STATUS_RUNNING = 0
	public static int STATUS_STOPPED = 1
	def workingDirectory = "" 
	def configuration = null
	def logOutFile = null
	def logErrFile = null
	def parentPid = null
	def childPids = null 
	def name = null
	def status = null  

	def setStatus( status ) {
		this.status = status 
	}
	def getStatusAsText(){
		if (this.status == this.STATUS_RUNNING ) { return "RUNNING" }
		if (this.status == this.STATUS_STOPPED ) { return "STOPPED" }
		return "UKNOWN" 
	}

	def getCommand(bundle) {
		def libPath = new File(workingDirectory + "/" + "./lib/*").getPath() 
		//return ["java","-cp",libPath,"com.liquidlabs.vso.deployment.ServiceTestHarness",  new JsonBuilder(this.configuration).toString().replace('"','\"')    ]
		return ["java","-cp",libPath,"com.liquidlabs.vso.deployment.ServiceTestHarness",  new File( workingDirectory + "/" + "./etc/services/"+bundle+".json").getPath()     ]
	}


	def get(key){
		return this.configuration[key] 
	}
	def getLogOutFile(){
		def bundle=this.getName() 
		def fileName= new File(workingDirectory + "/" + "./logs/$bundle" + ".log").getPath()
	}

	def getLogErrFile(){
		def bundle=this.getName() 
		def fileName= new File(workingDirectory + "/" + "./logs/$bundle" + ".err").getPath() 
	}


	def AppProcessContext(name,config){
		this.configuration=config
		this.name=name
		this.logOutFile = this.getLogOutFile() 
		this.status = AppProcessContext.STATUS_STOPPED 
	}

	def init(){
	}

}

