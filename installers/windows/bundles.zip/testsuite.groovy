import groovy.util.GroovyTestSuite
import junit.framework.Test
import junit.textui.TestRunner
import org.codehaus.groovy.runtime.ScriptTestAdapter

/*
	/etc/services
	new AppProcessContext( config ) 
	AppProcessContext.getOutLogFile() 
*/

def ats = new groovy.util.AllTestSuite()
def suite = ats.suite("tests","Test*.groovy")
junit.textui.TestRunner.run(suite) 

