import groovy.util.GroovyTestCase; 
import java.net.ServerSocket
import groovy.json.* 
/*
def commander=new Commander() 
commander.addWorker( "dummy", new DummyWorker() ) 
commander.register("module","action", { workers,args -> 
	def w=workers["dummy"] 
	return  w.method(args[0])
})


def server=new CommandServer(commander) 
server.init()
server.start() 
*/ 
public class DummyWorker{
	def method(arg1) {
		return  arg1;
	}
}


public class CommandServer{
	def commander=null
	def CommandServer(commander) {
		this.commander=commander; 
	}

	def init(){}

	def execute(command) {
		def module=command["module"]
		def action=command["action"]
		def args=command["args"]  
		def retVal = this.commander.invoke(module:module,
			action:action 
			,args:args) 
		
		return retVal 
	}
	def start() { 
		def server =new ServerSocket(55555) ;
		while(true){
			server.accept { socket -> 
				socket.withStreams { input,output -> 
					def reader = input.newReader()
					def buffer = reader.readLine()
					def message = [:] 
					try{ 
						println "Processing new Connection " 
						def cmd = new JsonSlurper().parseText(buffer) 
						message =this.execute(cmd) 
						respond(output,new JsonBuilder(message).toString())
					}catch(IllegalArgumentException e){
						message=["errorMessage":"Unknown Module or Action Requested"] 
						respond(output,new JsonBuilder(message).toString())
						e.printStackTrace()
					
					}catch(Exception e) {
						message=["errorMessage":"Invalid Json"] 
						respond(output,new JsonBuilder(message).toString())
						e.printStackTrace()
					}
				
				}
			
			}
	} 
}


def respond(handle,message){
	handle << new JsonBuilder(["response":message]).toString() <<  "\n"  
}



}

public class Commander{
	def workers=[:]
	def registry=[:] 

	def addWorker(name,worker){ 
		this.workers[name]=worker
	}
	def register(module,action,work){
		if (this.registry.containsKey(module)==false){
			this.registry[module] = [:]
		}
		this.registry[module][action] = work
		
	}
	def invoke(params){
		def module=params["module"]
		def action=params["action"]
		def args=params["args"].split() 
		def work = this.registry[module][action] 
		if ( this.registry.containsKey(module) == false){
			println "Could not find module:  $module " 
			return "Could not find module: $module " 
		}

		if ( this.registry[module].containsKey(action) == false){
			println "Could not find $action in  $module " 
			println " Contents of $module are "  + this.registry[module] 
			return "Could not find $action in $module " 
		}

		return work(this.workers,args); 
	}
}
