import groovy.util.*
import groovy.json.*;
import groovy.util.logging.* 
import groovy.util.GroovyTestCase; 
import org.apache.http.client.* 
import org.apache.http.client.methods.*;
import groovyx.net.http.*;
import groovyx.net.http.RESTClient;
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.JSON 

import org.apache.log4j.* 

/*
	bundles.conf 
	
*/
//unzip(src:"./bundles/UnixApp-1.1.zip",dest:"./test/UnixApp-1.1",overwrite:"true")
//System.exit(0) 
/*
def bundles=new Bundles([
	"manager":"saas.logscape.com" 
	,"token":"123:456:789"
	,"apps":["unixapp","windowsapp"]
]) 

bundles.workingDirectory="./"
bundles.init() 
bundles.updateConfigs() 
*/
//bundles.install("unixapp") 
//bundles.install("windowsapp") 
//bundles.install("mysqlapp") 


/*bundles.getVersion("windowsapp")
bundles.updateServiceConfig("unixapp") 
bundles.update("unixapp") 
bundles.deploy("unixapp") */ 

/*
bundle.install("unixapp") 
	is really 
	bundle.updateServiceConfig("unixapp")
	bundle.update("unixapp")
	bundle.deploy("unixapp") 
*/

//println bundles.getRepos("logscape")
//println bundles.getAppList() 
/*
//def http=new HTTPBuilder("https://github.com/logscape/unixapp/raw/master/dist/UnixApp-1.1.zip")
def http=new HTTPBuilder("https://github.com/")

http.get(path:"/logscape/unixapp/raw/master/dist/UnixApp-1.1.zip") { resp,reader -> 
	resp.headers.each { h ->
		println "{$h.name} : ${h.value} " 
	}
	def file = new FileOutputStream("test.zip")
	def out = new BufferedOutputStream(file)
	out << reader 
	out.close() 
}
*/


public class TestBundles extends GroovyTestCase {
	def bundles=null;

	void setUp(){
		this.bundles= new Bundles([
			"manager":"10.28.1.160:11000" 
			,"token":"123:456:789"
			,"apps":["unixapp","windowsapp"]
		])  
	}
	
	void testUpdate(){
		this.bundles.init() 
		this.bundles.update("unixapp")
		assertTrue( new File("./bundles/UnixApp-1.1.zip").exists()  ) 
	}
	void testDeploy(){
		this.bundles.init()
		this.bundles.deploy("unixapp") 
		def deployFolder = this.bundles.getDeployFolder("unixapp") 
		assertTrue ( new File("./$deployFolder").exists()  ) 
	}
	/*
	void testUpdateAll(){
		this.bundles.init() 
		this.bundles.updateAll("")
		fail("Not Yet Implemented")

	}*/

	void testGetDeployFolder(){
		this.bundles.init()
		def deployFolder=this.bundles.getDeployFolder("unixapp")
		def expected="UnixApp-1.1" 
		assertEquals(deployFolder,expected)
	}
	void testGetZipName(){
		this.bundles.init() 
		
		def zipName = this.bundles.getZipName("unixapp") 
		assertEquals("UnixApp-1.1.zip",zipName)
	}
	void testGetRepos(){
		def repos=this.bundles.getRepos("logscape") 
		def currentAppListSize = 12
		assertEquals(currentAppListSize,repos.size())
	}
	void testGetBundleGitURL(){
		def url="https://github.com/logscape/unixapp"	
		this.bundles.init() 
		def gitURL=this.bundles.getBundleGitURL("unixapp")
		assertEquals(url,gitURL)
	}

	void testGetAppList(){
		this.bundles.init() 
		def appList=this.bundles.getAppList()
		assertTrue( appList.size() ==  2 ) 
	}
	void testGetBundleVersion(){
		def version="1.1"
		def bundleVersion=this.bundles.getVersion("unixapp")
		assertEquals(version,bundleVersion)
	}
	void testGetDistURL(){
		this.bundles.init() 
		def distURL="https://github.com/logscape/unixapp/blob/master/dist/UnixApp-1.1.zip"
		def bundleDistURL=this.bundles.getDistURL("unixapp") 
		assertEquals(distURL,bundleDistURL) 
	}

}

public class PathBuilder {
	def rootPath = null 
	def PathBuilder(rootPath){
		this.rootPath=rootPath		
	}
	def getPath(path){
		def newPath =  rootPath + "/" + path 
		println "[PathBuilder] Translating $rootPath -> $newPath " 
		return newPath 
	}
} 

@Log4j 
public class Bundles {
	def workingDirectory = "" 
	def bundles=[]
	def bundlesConfPath="./"
	def deployPath="./" 
	def repos = null
	def appList = null
	def configuration=null
	def bundleDeployPath = "./bundles"
	def Bundles(config){
		this.configuration=config
		this.bundles=config["apps"]
	}

	def getDistURL(bundle){
		//def distURL="https://github.com/logscape/unixapp/blob/master/dist/UnixApp-1.1.zip"
		def version = getVersion(bundle) 
		def url=this.appList[bundle] // "https://github.com/logscape/unixapp"
		def zipName = bundle.replace("app","App") 
		zipName  = zipName[0].capitalize()  + zipName[1..-1] 
		def distURL="https://github.com/logscape/$bundle/blob/master/dist/"+zipName+"-$version"+".zip"
		return distURL
		
		
	}
	def getDeployFolder(bundle){
		def url=this.appList[bundle] 
		def zipName = getBundleZipFileName(bundle) 
		def folder=zipName.split(".zip")[0] 
		return new File(workingDirectory + "/" +  folder).getPath()  
	}

	def getZipName(bundle){
		return getDistURL(bundle).split("/")[-1]
	}
	def getVersion(bundle){
		def http=new HTTPBuilder("https://github.com/")
		def version="" 
		http.get(path:"/logscape/$bundle/raw/master/dist/VERSION") { resp,reader -> 
			/*resp.headers.each { h ->
				println "{$h.name} : ${h.value} " 
			}*/
			version = reader.readLine()
		}
		return version 
	}
	def getBundleGitURL(bundle){
		return this.appList[bundle] 
	}
	def getBundleZipFileName(bundle){
		def filename=getZipName(bundle)
		//return this.bundleDeployPath+"/"+filename
		return filename
	
	}	
	def getBundlesFileName(){
		return new File(workingDirectory + "/" +  bundlesConfPath+"/bundles.conf").getPath() 
	}
	def get(url,type){
		// https://api.github.com/users/logscape/repos
	}
	def getRepos(user){
		def data=null
		def urls=[] 
		println "[repos.json] " +  new File(workingDirectory  + "/" + "./repos.json" ).getPath()
		println "[repos.json ]" +  new File(workingDirectory + "/" + "./repos.json").exists() 
		
		if ( new File(workingDirectory + "/" + "./repos.json").exists()){ 
			println "Loading cached copy" 
			data=new JsonSlurper().parseText( new File(workingDirectory + "./repos.json").text )
		}else{
			println "Fetching repos [$user] "
			def github = new RESTClient("https://api.github.com/")
			def resp=github.get(path:"/users/logscape/repos",headers:["User-Agent":"Mozilla 5.1"])
			data=resp.data
		}

		data.each(){ entry -> 
			if (entry.html_url.contains("app")) {
				urls.add(entry.html_url) 
			}
		}
		return urls  
	}
	def getAppList(){
		def appList=[:] 
		for(def repoURL:this.repos){
			def name=repoURL.split("/")[-1]
			if (name in this.bundles ){
				appList[name]= repoURL 
			}
		}
		return appList 
	}

	def updateConfigs(){
		log.info "UPDATECONFIGS"
		for(def bundle:this.getAppList().keySet()){
			this.updateServiceConfig(bundle)
		}
		println "exiting..."	
	}
	def updateServiceConfig(bundle){
		def f = new File(workingDirectory + "/" + "./etc/services/"+bundle+".json")
		f.createNewFile() 
		// {"token":"123:456:789","output":[{"port":"9991","type":"SocketOut","remoteAddr":"10.28.1.160"}],"bundleName":"./MysqlApp-1.0/MysqlApp.bundle","serviceName":"*","tag":"moo"}
		log.info "UPDATE SERVICE CONFIGS [$bundle]"
		def token=this.configuration["token"]
		def remoteAddr=this.configuration["manager"]
		def deployFolder=getZipName(bundle).split("\\.zip")[0] 
		def bundleConfig =  deployFolder.split("-")[0] + ".bundle" 
		def fullbundleName=new File(workingDirectory + "/"  + "$deployFolder/$bundleConfig").getPath() 
		def config=[
			'token':'123:456:789'
			,'output':[['port':'9991','type':'SocketOut','remoteAddr':"$remoteAddr"]]
			,'bundleName':"$fullbundleName"
			,'serviceName':'*' 
			, 'tag':'moo'
		]
		def line =  new JsonBuilder(config).toString() 
		f << line 
		log.info "UPDATE:SERVICE:CONFIG updating service config  \n\t " +  config 
		//f.close()   
	}

	def update(bundle){
		def zipFileName = this.getBundleZipFileName(bundle)

		if (new File(workingDirectory + "/" + this.bundleDeployPath + "/" + zipFileName).exists() == true){
			log.info "UPDATE $zipFileName already exists ... skipping download " 
			return
		}
		log.info "UPDATE fetch $zipFileName from  [ /logscape/$bundle/raw/master/dist/$zipFileName]"  
		def http=new HTTPBuilder("https://github.com/")
		http.get(path:"/logscape/$bundle/raw/master/dist/$zipFileName") { resp,reader -> 
			resp.headers.each { h ->
				println "{$h.name} : ${h.value} " 
			}
			log.info  "UPDATE downloading to " + new File( workingDirectory + "/" + this.bundleDeployPath + "/" + zipFileName).getPath()
			def file = new FileOutputStream(new File( workingDirectory + "/" + this.bundleDeployPath + "/" + zipFileName).getPath() ) 
			def out = new BufferedOutputStream(file)
			out << reader 
			out.close() 
		}
	
	}

	def deploy(bundle){
		def zipFileName = this.getBundleZipFileName(bundle) 
		def destPath = this.getDeployFolder(bundle) 
		if (new File( this.bundleDeployPath + "/" + zipFileName ).exists() == false ){
			println "Please Install ZIP FILE!" 
		}
		//unzip(src:"./bundles/UnixApp-1.1.zip",dest:"./test/UnixApp-1.1")
		log.info "DEPLOY $bundle "
		log.info "DEPLOY [$bundle]  $zipFileName -->  $destPath " 
		unzip(src:new File(workingDirectory + "/" + this.bundleDeployPath + "/" + zipFileName).getPath(),dest:new File(workingDirectory +"/" + "./"+destPath).getPath())
	}
	/*
	def loadBundleConf(){
		new File(getBundlesFileName()).text.split("\n").each(){ line -> 
				if(line.toLowerCase().contains("app")){
					def bundleName=line.trim()
					this.bundles.add(bundleName)
				}
			}
	}*/
	def install(bundleName){
		log.info "INSTALL [$bundleName]" 
		try{
			getVersion(bundleName)
			updateServiceConfig(bundleName) 
			update(bundleName) 
			deploy(bundleName)  
		}catch(Exception e){
			log.error("INSTALL [ $bundleName ] Failed:",e) 
		}
	}
	def init(){
		//this.loadBundleConf()
		this.repos = getRepos("logscape") 
		this.appList = getAppList() 
		log.info "INIT Bundles "	
		for(def bundleName:this.bundles){
				if (this.appList.containsKey(bundleName)==false) {
					println "[WARNING] - $bundleName does not exist in the Logscape App Repostiory" 
				}
		}
		
		
	} 



	def create(path,zipEntry,inputStream){
		if (path[-1] == '/') { path = path[0..-2] } 
		def destFileName= path + "/" + zipEntry 
		if (zipEntry.isDirectory()){
			println "Creating Folder" + destFileName
			new File(destFileName).mkdirs() 
		}else{
			println "Creating File" + destFileName
			def file = new FileOutputStream(destFileName)
			def out = new BufferedOutputStream(file)
			out << inputStream  
			out.close() 
		}
		
	}

	def unzip(params){
		def zipFile = new java.util.zip.ZipFile(new File(params["src"]))
		def dest=params["dest"] 
		new File(dest).mkdirs() 
		zipFile.entries().each { entry -> 
			create(dest,entry,zipFile.getInputStream(entry))
		}
	}



}
