//println System.getProperty("user.dir")
//def command = 'java -cp ../lib/main.jar;../lib/http-builder-0.7/dependencies/commons-collections-3.2.1.jar;../lib/http-builder-0.7/dependencies/xercesImpl-2.9.1.jar;../lib/http-builder-0.7/dependencies/xml-apis-1.4.01.jar;../lib/http-builder-0.7/dependencies/xml-resolver-1.2.jar;../lib/http-builder-0.7/dependencies/json-lib-2.3-jdk15.jar;../lib/http-builder-0.7/dependencies/commons-logging-1.1.1.jar;../lib/commons-io-1.4.jar;../lib/http-builder-0.7/dependencies/httpcore-4.2.1.jar;../lib/http-builder-0.7/dependencies/httpclient-4.2.1.jar;../lib/junit-4.11.jar;../lib/hamcrest-core-1.3.jar;../lib/vso.jar;../lib/joda-convert-1.1.1.jar;../lib/http-builder-0.7.jar;../lib/junit-4.11.jar;../lib/log4j-1.2.15.jar;../lib/classes/groovy-all-1.8.7.jar;../lib/log4j.properties groovy.lang.GroovyShell ../lib/main.groovy workingDirectory="./.."'
//def proc = command.execute()
//println "[BOOTSTRAPPER]Attempting to start Collector"
//proc.waitFor()
//println "[BOOTSTRAPPER]Collector Exited"
def command="boot.bat"
def proc = command.execute() 
proc.waitFor()
